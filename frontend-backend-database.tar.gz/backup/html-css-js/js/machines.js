document.getElementById('serverForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const serverData = {
        ipAddress: document.getElementById('ipAddress').value,
        model: document.getElementById('model').value,
        cpuCores: document.getElementById('cpuCores').value,
        memory: document.getElementById('memory').value
    };

    const request = new Request('http://192.168.56.88:8000/machines', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(serverData)
    })

    fetch(request)
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Server details saved successfully!');
            document.getElementById("serverForm").reset();
        } else {
            alert('Failed to save server details.');
        }
    })
    .catch((error) => {
        console.error('Error:', error);
        alert('An error occurred while saving server details.');
    });
});



// Define a function to fetch machines data from the backend
function fetchMachines() {
    fetch('http://192.168.56.88:8000/machines/') // Replace with your backend API endpoint
    .then(response => response.json())
    .then(data => {
        const tableBody = document.getElementById('machinesTable').getElementsByTagName('tbody')[0];

        // Clear existing table rows
        tableBody.innerHTML = '';

        // Iterate through each machine object in the data array
        data.forEach(machine => {
            const row = tableBody.insertRow();
            row.insertCell(0).innerText = machine.ipAddress;
            row.insertCell(1).innerText = machine.model;
            row.insertCell(2).innerText = machine.cpuCores;
            row.insertCell(3).innerText = machine.memory;
        });
    })
    .catch(error => {
        console.error('Error fetching machines:', error);
        alert('An error occurred while fetching machines.');
    });
}

// // Fetch and display machines on page load
// fetchMachines();


// Function to update machines periodically
function updateMachinesPeriodically(interval) {
    // Fetch and display machines immediately
    fetchMachines();

    // Set interval to fetch and display machines every 'interval' milliseconds
    setInterval(fetchMachines, interval);
}

// Call the function to update machines every 5 seconds (5000 milliseconds)
updateMachinesPeriodically(5000); // Adjust the interval as needed