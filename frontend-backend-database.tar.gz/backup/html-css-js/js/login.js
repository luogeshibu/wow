// function getMyPublicIpAddress() 
// {
//     xhttp = new XMLHttpRequest();
//     xhttp.onreadystatechange = function() 
//     {
//         if (this.readyState == 4 && this.status == 200) 
//         {
//             document.getElementById("demo").innerHTML = JSON.parse(this.responseText).YourFuckingIPAddress;
//         }
//     };
//     xhttp.open("GET", "https://wtfismyip.com/json", true);
//     xhttp.send();
// }

// function myFunction()
// {
//     document.getElementById("demo").innerHTML = "Paragraph changed.";
// }

// method 1: you will need to call the function to make it work , and it change the paragraph to "Paragraph changed." in p element with id demo
// method 2: you can set a trigger button to call the function. just like this <button type="button" onclick="myFunction()">Try it</button>
// getMyPublicIpAddress(); // Call the function automaticly.

// function helloWorld()
// {
//     alert("Hello world! by shibu")
// }


document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const username = document.getElementById('useremail').value;
    const password = document.getElementById('pwd').value;

    const request = new Request('http://192.168.56.88:8000/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })

    fetch(request)
    .then((response) => {
        if (response.status === 200) {
            return response.json();
        } else if (response.status === 401) {
            return response.json();
        } else {
            throw new Error("Something went wrong on API server!");
        }
      })
    .then(data => {
        if (data.success) {
            alert(data.message);
            // Redirect to another page or perform other actions
            window.location.href = "../index.html";
        } else {
            alert(data.detail);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred. Please try again later.');
    });
});


