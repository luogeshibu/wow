# from fastapi import FastAPI, HTTPException
# from pydantic import BaseModel
# from fastapi.middleware.cors import CORSMiddleware

# app = FastAPI()

# # Allow CORS for the frontend server
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],  # Update this with your frontend URL
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# class LoginRequest(BaseModel):
#     username: str
#     password: str

# @app.post("/login")
# def login(request: LoginRequest):
#     if request.username == "user" and request.password == "pass":
#         return {"success": True, "message": "Login successful! Powered by FastAPI."}
#     else:
#         raise HTTPException(status_code=401, detail={"success": False, "message": "Invalid username or password. Powered by FastAPI."})

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)


import ldap
from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import pymongo

app = FastAPI()

# Connect to MongoDB
client = pymongo.MongoClient("mongodb://root:123456@192.168.56.88:27017")


# Access the database
db = client["bni_database"]

# # Access the collection
# collection = db["items"]

# Allow CORS for the frontend server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Update this with your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# this item is not used in my project, only for demo
class Item(BaseModel):
    name: str
    description: str | None = None
    price: float
    tax: float | None = None


class LoginRequest(BaseModel):
    username: str
    password: str

class Machine(BaseModel):
    ipAddress: str
    model: str
    cpuCores: int
    memory: int
    # status: bool

class Tasks(BaseModel):
    taskName: str
    taskDescription: str
    taskStatus: str
    taskDueDate: str


def authenticate_user(username: str, password: str) -> bool:
    # print(username, password)
    # print("Authenticating user...")
    ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
    l = ldap.initialize("ldaps://ad.harman.com:636")
    l.set_option(ldap.OPT_REFERRALS, 0)
    l.set_option(ldap.OPT_PROTOCOL_VERSION, 3)
    l.set_option(ldap.OPT_X_TLS, ldap.OPT_X_TLS_DEMAND)
    l.set_option(ldap.OPT_X_TLS_DEMAND, True)
    l.set_option(ldap.OPT_DEBUG_LEVEL, 255)
    try:
        l.simple_bind_s(username, password)
        return True
    except ldap.INVALID_CREDENTIALS:
        print("Invalid credentials")
        return False
    except ldap.SERVER_DOWN:
        print("Server is down")
        return False
    except ldap.LDAPError as e:
        print("LDAP error:", e)
        return False
    finally:
        # Unbind from the server
        l.unbind_s()
   

@app.post("/login")
def login(request: LoginRequest):
    if authenticate_user(request.username, request.password):
        return {"success": True, "message": "Login successful!"}
    else:
        raise HTTPException(status_code=401, detail="Invalid username or password.")


# from fastapi offical doc.
@app.get("/items/{item_id}")
async def read_item(item_id: int):
    return {"item_id": item_id}


@app.post("/items/")
async def create_item(item: Item):
    # Insert the item into the database

    # Access the collection
    collection = db["items"]
    # Insert the document into the collection
    try:
        result = collection.insert_one(item.model_dump())
        print(f"Document inserted with _id: {result.inserted_id}")
        return {"success": True, "message": f"Document inserted with _id: {result.inserted_id}"}
    except Exception as e:
        print("An error occurred while inserting the document:", e)
        return {"success": False, "message": "An error occurred while inserting the document."}


# This is working for my BNI CN WORKSITE API
@app.get("/machines/")
async def get_machines():
    # Access the collection
    collection = db["machines"]
    # Find all documents in the collection
    # machines = list(collection.find())
    machines = list(collection.find({}, {'_id': 0}))
    # return {"machines": str(machines)}
    return machines


@app.post("/machines/")
async def add_machine(machine: Machine):
    # Insert the item into the database

    # Access the collection
    collection = db["machines"]
    # Insert the document into the collection
    try:
        result = collection.insert_one(machine.model_dump())
        print(f"Document inserted with _id: {result.inserted_id}")
        return {"success": True, "message": f"Document inserted with _id: {result.inserted_id}"}
    except Exception as e:
        print("An error occurred while inserting the document:", e)
        return {"success": False, "message": "An error occurred while inserting the document."}


@app.get("/tasks/")
async def get_tasks():
    # Access the collection
    collection = db["tasks"]
    # Find all documents in the collection
    # tasks = list(collection.find())
    tasks = list(collection.find({}, {'_id': 0}))
    # return {"tasks": str(tasks)}
    return tasks


@app.post("/tasks/")
async def add_task(task: Tasks):
    # Insert the item into the database

    # Access the collection
    collection = db["tasks"]
    # Insert the document into the collection
    try:
        result = collection.insert_one(task.model_dump())
        print(f"Document inserted with _id: {result.inserted_id}")
        return {"success": True, "message": f"Document inserted with _id: {result.inserted_id}"}
    except Exception as e:
        print("An error occurred while inserting the document:", e)
        return {"success": False, "message": "An error occurred while inserting the document."}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
